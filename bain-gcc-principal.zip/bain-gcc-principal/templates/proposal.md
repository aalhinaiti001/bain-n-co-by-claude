# Proposal Shell

> Client-facing sections 1–7. Section 8 is internal — strip before sending.

## 1. Situation and problem
[Client's problem, restated sharper than they stated it. 3–5 sentences. End with the decision this work enables and its deadline.]

## 2. Our perspective
[Day-one hypothesis and the 2–3 questions that will decide it. Signal insight; do not give away the answer.]
[If government/GRE/SWF/agenda-exposed client: one precise national-agenda sentence.]

## 3. Approach
[Module table — one row per module:]

| Module | Question answered | Approach | Output | Client decision enabled | Weeks |
|---|---|---|---|---|---|
| 1 | | | | | |

[Note evidence standards: triangulated sources, assumption log, [VERIFY] discipline.]

## 4. Team and governance
[Named senior team and continuity commitment. Steering cadence and membership. Client-side asks: sponsor time, data access, working-team members.]

## 5. Timeline
[Milestone view. Confirm it has been checked against Ramadan/Eid/Hajj windows and the client's working week — state the working-week assumption explicitly.]

## 6. Fees and terms
[Fee framed against value at stake. Structure: fixed / phased / other. Payment schedule. Expenses basis. Confidentiality and independence clauses per firm standard.]

## 7. Relevant experience
[2–4 anonymized, specific case vignettes: situation → what we did → result. No client names. No invented cases — omit rather than fabricate.]

---

## 8. INTERNAL — pre-wiring note (strip before sending)
- Real decision-maker and evaluator: [ ]
- Sponsor strength and exposure: [ ]
- Socialization sequence before submission: [who, by whom, when]
- Known/likely objections and responses: [ ]
- Competitive situation and our angle: [ ]
- Soft-no watch items: [ ]
