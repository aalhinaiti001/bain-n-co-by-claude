# Issue Tree Shell

**Sharpened question:** [One sentence: decision, decision-maker, deadline.]

**Day-one hypothesis:** [Falsifiable answer + one-line rationale.]

## Tree
- **H1. [Testable statement, not a topic]**
  - H1.1 [Sub-hypothesis] — Kill test: [analysis/fact that would disprove] — Source: [ or [VERIFY] + route] — Effort: S/M/L — Priority: [1–n]
  - H1.2 [ ] — [ ] — [ ] — [ ] — [ ]
- **H2. [ ]**
  - H2.1 [ ] — ...
- **H3. [ ]**
  - ...

**MECE check:** [What could fall between branches; confirm covered or add branch.]

**Relationship-routed evidence:** [Branches whose test runs through conversations, not data — route to stakeholder plan: which branch, which person, which channel.]

**Week-1 priorities:** [2–3 kill tests that swing the answer, with owners.]
