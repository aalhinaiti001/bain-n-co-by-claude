# Weekly Steering Committee Update Shell

> One page. Written to be forwarded upward untouched.

**Engagement:** [ ]  **Week:** [n of N]  **Date:** [ ]

## 1. Headline
[One sentence: where the answer stands now vs. last week.]

## 2. Progress against the hypothesis
- [Hypothesis branch] — [tested / in progress / next] — [what we learned, so-what]
- [ ] — [ ] — [ ]

## 3. Decisions needed this week
| Decision | Owner | Needed by | Consequence of delay |
|---|---|---|---|
| | | | |

## 4. Risks and blockers
[Max 3. Each with mitigation and owner. Include data-access and calendar risks explicitly.]

## 5. Next week
[3–5 dated items. Note any calendar constraints (Ramadan hours, Eid, travel).]

**Asks of the committee:** [Specific: introductions, data, sponsor time. Small early, larger once trust is banked.]
