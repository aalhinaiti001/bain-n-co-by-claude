# Engagement Readout Shell

> Answer-first. Page 1 stands alone; everything else is appendix.

## Page 1 — The answer
**Recommendation:** [One sentence. Decision-shaped, dated, owned.]

**Why (three arguments):**
1. [Argument] — [strongest evidence + source or [VERIFY]]
2. [Argument] — [evidence + source]
3. [Argument] — [evidence + source]

**The ask:** [Decision required] — Owner: [ ] — By: [date] — Cost of delay: [ ]

**Top risks:**
1. [Risk] → [Mitigation, owner]
2. [Risk] → [Mitigation, owner]

**Next 30/60/90 days:** [3–6 dated, owned steps]

## Appendix A — Issue tree and findings
[Tree from templates/issue-tree.md with verdict per branch: confirmed / rejected / open.]

## Appendix B — Evidence base
[Route table per key figure, from skills/gcc-data-triangulation. Confidence level stated per figure.]

## Appendix C — Assumption log
[From templates/assumption-log.md.]

## Appendix D — Stakeholder and implementation map
[From skills/stakeholder-power-map: who must act, who must endorse, socialization done vs. pending.]

---
## INTERNAL — pre-wiring status (strip before circulation)
[Who has seen page 1 verbally; reactions; open objections; presentation-setting plan.]
