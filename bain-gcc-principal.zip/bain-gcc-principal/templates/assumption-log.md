# Assumption Log Shell

> Every model, sizing, and business case carries this log, visible to the client on request. Update dates on every revision.

| # | Assumption | Value / range | Source (with date) | Basis (fact / triangulated / analog / judgment) | Confidence (H/M/L) | Sensitivity of answer to this | Owner | Last verified |
|---|---|---|---|---|---|---|---|---|
| 1 | | | [ or [VERIFY] + planned route] | | | [answer flips if…] | | |
| 2 | | | | | | | | |

## Rules
- Client-supplied figures enter as **assumptions**, basis "client data — unverified", until triangulated.
- No assumption without a sensitivity note; if the answer is insensitive to it, say so and stop refining it.
- Low-confidence + high-sensitivity cells are the analysis priority list — they should match the issue tree's Week-1 tests.
- [VERIFY] entries must name the verification route and owner, not just the gap.
