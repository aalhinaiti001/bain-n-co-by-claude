---
name: gcc-data-triangulation
description: Establish a defensible estimate in GCC markets where official statistics are thin, lagged, or policy-shaped — by triangulating independent evidence routes and stating confidence explicitly. Use whenever the user needs a market size, growth rate, share, wage, price, or volume figure for a GCC market; questions the reliability of a statistic or client-supplied number; or asks "how would we even know this?" Also invoke whenever any other skill hits a [VERIFY] placeholder that must be resolved.
---

# GCC Data Triangulation

## Trigger conditions
- Any request for a GCC market figure, or any `[VERIFY]` placeholder that must become a number.
- Doubt about an official statistic, broker report, or client data point.
- Sanity-checking a business case built on someone else's numbers.

## Required inputs
1. The quantity to estimate, its use (sizing vs. decision threshold — precision needs differ), and the tolerance ("do we need ±10% or just the order of magnitude?").
2. What the client or public sources already claim, with provenance.
3. Access available: expert calls, client internal data, channel checks, site visits.

## Process
1. **Classify the data environment.** For the quantity in question: is there a credible official series `[VERIFY source and lag]`, a regulated disclosure route (listed-company filings, central bank, regulator reports), or nothing? Assume official series may be lagged, rebased, or shaped by policy narrative — treat them as one input, never the anchor by default.
2. **Build ≥3 independent routes.** Standard GCC routes:
   - *Supply side*: capacity × utilization from operator counts, licenses issued, import records `[VERIFY availability per country]`.
   - *Demand side*: population/household or enterprise base × penetration × spend, with each factor sourced separately.
   - *Analog/benchmark*: a structurally comparable market adjusted for stated differences (never "regional average" hand-waving — name the analog and the adjustment).
   - *Ground truth*: expert interviews, channel checks, tender records, job-posting or real-estate proxies. In relationship-driven markets, a well-chosen practitioner conversation often beats a published report — log it as an interview source with date.
3. **Independence check.** Confirm the routes don't share a hidden common source (many paid reports republish the same base figure). Two routes citing the same origin count as one.
4. **Converge and bound.** Present the range, the modal estimate, and why the routes diverge. Divergence is information — usually a definitional gap (nationals vs. total population, licensed vs. active operators, contracted vs. delivered).
5. **State confidence** on a three-level scale (High: 3+ independent routes converge / Medium: 2 routes or wide range / Low: single route or analog only) and what would raise it.
6. **Log everything** in `templates/assumption-log.md`: every factor, source, date, confidence, sensitivity to the answer.

## Output structure
For each quantity: **Estimate (range + modal value or `[VERIFY]` if honesty requires it)** → routes table (Route | Method | Result | Source | Independence) → divergence explanation → confidence level → what would firm it up → assumption-log entries.

## Anti-patterns
No single-source figures. No precision theater (a false decimal on a Low-confidence number). No silent adoption of client data. No invented statistics — if a route can't be executed in-session, output the method and `[VERIFY]`, never a guessed number.
