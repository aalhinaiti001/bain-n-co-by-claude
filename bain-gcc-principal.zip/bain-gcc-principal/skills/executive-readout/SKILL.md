---
name: executive-readout
description: Compress any body of analysis into a one-page, answer-first executive readout suitable for a GCC C-suite, board, ministry, or SWF audience — plus a private pre-wiring note. Use whenever the user asks to summarize findings for executives, write a one-pager, prepare a steering-committee or board message, "make this exec-ready", or distill a long document or analysis into its answer.
---

# Executive Readout

## Trigger conditions
- "Summarize for the CEO/board/minister" / "one-pager" / "exec summary" / "what do we tell the SteerCo?"
- Any long analysis that must now change a decision.

## Required inputs
1. The underlying analysis or draft (or a summary of findings).
2. Audience: who reads it, their archetype, their current stance, and whether it will be read privately or presented in a group setting.
3. The decision being asked of them, and the deadline.

## Process
1. **Extract the answer** — one sentence, declarative, decision-shaped ("Approve the JV structure by [date]; defer the second market"). If the analysis doesn't support one sentence, the analysis isn't done; say so.
2. **Pyramid the support**: exactly three supporting arguments, each with its single strongest piece of evidence. Evidence must carry a source or `[VERIFY]`.
3. **State the ask**: the decision, its owner, the date, and what happens if deferred.
4. **Risks honestly**: top two risks with mitigation and owner. Never bury the risk that the audience already suspects — naming it builds credibility.
5. **Calibrate for the setting**:
   - *Private read*: full candor, direct language.
   - *Group/majlis-style presentation*: the document ratifies what has been socialized. Nothing in it should surprise a senior attendee. If the user hasn't pre-wired, flag it and produce the pre-wiring note.
   - Never phrase anything as a public correction of a senior client's stated position; route disagreements to the private channel.
6. **National-agenda line**: for government, GRE, or SWF audiences, one sentence connecting the recommendation to the relevant agenda (`references/national-vision-agendas.md`). One sentence — not a theme.
7. **Attach the pre-wiring note** (internal): who must see this before the meeting, in what order, expected objections, and the fallback if a soft no appears.

## Output structure
One page, in this order: **Answer** (1 sentence) → **Context** (2–3 sentences) → **Why** (3 numbered arguments, one line of evidence each) → **The ask** (decision, owner, date) → **Risks** (2, with mitigations) → **Next steps** (dated). Then a clearly separated **Internal pre-wiring note**. Prose and short numbered lines — no decorative formatting.

## Anti-patterns
No "background → analysis → options → considerations" build-up. No more than one page. No options menu where a recommendation is owed. No so-what-free exhibits referenced. No jargon.
