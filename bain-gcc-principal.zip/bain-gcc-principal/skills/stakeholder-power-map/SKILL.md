---
name: stakeholder-power-map
description: Build a two-layer stakeholder map for a GCC engagement — the formal org chart versus the real influence network — and turn it into a socialization plan. Use whenever the user mentions stakeholders, decision-makers, "who really decides", sponsors, org politics, board or family dynamics, pre-wiring a recommendation, or is preparing for any senior GCC meeting or steering committee. Also invoke proactively at the start of any new engagement.
---

# Stakeholder Power Map

## Trigger conditions
- "Who do we need on side?" / "Map the stakeholders" / "Who actually decides?"
- Preparation for any senior presentation, steering committee, or board/majlis-style session.
- Start of any new engagement (invoke proactively; note it if the user hasn't asked).

## Required inputs
1. Client organization and archetype (`references/client-archetypes.md`).
2. The decision the engagement drives.
3. Known names/roles: sponsor, CEO, chair, family principals, board, relevant government or SWF counterparties.
4. Any observed behavior: who defers to whom, who was consulted before past decisions, who sits closest to the principal.

## Process
1. **Layer 1 — Formal map.** Org chart of titled authority over the decision: approver, budget holder, implementer.
2. **Layer 2 — Real influence map.** For each formal actor, identify:
   - *Gatekeepers*: chief of staff, family office head, trusted advisor whose private endorsement is required before anything reaches the principal.
   - *Veto holders without title*: a founder emeritus, a senior family member outside management, a board member with sovereign or ministry ties.
   - *The sponsor's own standing*: is your sponsor a decision-maker, a conduit, or exposed? A weak sponsor changes the whole plan.
   - *Network ties (wasta layer)*: mapped as institutional relationships — who owes whom, who appointed whom, which SWF or ministry relationship constrains the client. Record as relationship facts, not personality judgments; mark unverified ties `[VERIFY]`.
3. **Classify each actor**: Decide / Veto / Influence / Implement / Inform, plus current stance (champion, neutral, skeptic, unknown) and evidence for the stance.
4. **Flag divergences** between the two layers — every divergence is a risk or a route.
5. **Socialization plan.** Sequence of private conversations before any group presentation: who hears it first, from whom, in what setting, with what version of the message. Rule: the formal meeting ratifies; it does not decide. Include a soft-no listening plan — what deferral or silence from each actor would mean and the private re-approach if it appears.

## Output structure
Table (or Mermaid diagram if asked): Actor | Formal role | Real role | Stance | Evidence | What they need to hear | Who delivers it | When. Followed by a five-line socialization sequence and the top two map risks.

## Anti-patterns
No psychoanalysis of individuals. No stance without stated evidence. No map that treats the org chart as the influence map. Never write anything about a named individual you would not want them to read.
