---
name: client-proposal-writer
description: Draft a Bain-style consulting proposal or letter of engagement for a GCC client — answer-first, scoped in modules, priced in ranges, culturally pre-wired. Use whenever the user asks to write, draft, respond to, or improve a proposal, RFP response, engagement letter, scope document, or "note to the client on how we'd help", for any GCC client archetype.
---

# Client Proposal Writer (GCC)

## Trigger conditions
- Any request to draft or sharpen a proposal, RFP response, or engagement scope for a GCC client.
- "How would we pitch this?" / "Turn these notes into a proposal."

## Required inputs
1. Client name/archetype and the individual sponsor (title and real influence, if known).
2. The problem as the client stated it — verbatim if possible.
3. Scope boundaries, duration, team shape, and fee posture (fixed/range/omitted).
4. Competitive context: sole-source, shortlist, or open RFP.
5. Any history with the client or its network.

## Process
1. **Reframe the problem.** Open the proposal with the client's problem restated sharper than they stated it — this is the single biggest win-signal. State the day-one hypothesis without giving away the full answer.
2. **Anchor to the national agenda** where the client is a ministry, GRE, SWF, or agenda-exposed conglomerate: name the specific program or vision pillar the work advances (`references/national-vision-agendas.md`). For multinationals and PE, anchor to their investment thesis instead.
3. **Structure scope in modules** with named outputs and decision points, not activities. Each module: question answered → approach → output → client decision enabled.
4. **Handle the relationship layer explicitly but privately.** The written document stays formal. Sponsor dynamics, majlis pre-wiring, and who must be consulted before signature are captured in a separate "cover note to self" section the user can strip — never in the client-facing text.
5. **Localization and calendar.** Timeline must show awareness of Ramadan/Eid/Hajj windows and the country's weekend. Team plan should note national talent inclusion where the client values it, framed as capability, not quota.
6. **Commercial discipline.** Fees framed against value at stake, never against effort. No discounting language. If the user gives no fee guidance, present structure options (fixed, phased, success-linked `[VERIFY feasibility per client type]`) and recommend one.
7. **Qualifications**: reference anonymized experience only ("a leading regional sovereign investor") — never named clients, never invented cases.

## Output structure
Use `templates/proposal.md`:
1. Situation and problem (client's words, sharpened)
2. Our answer-first perspective (hypothesis, not conclusion)
3. Approach and modules
4. Team and governance
5. Timeline (calendar-aware)
6. Fees and terms
7. Why us (anonymized, specific)
+ Internal cover note: pre-wiring plan, real decision-maker, known objections.

## Anti-patterns
No boilerplate firm-history paragraphs. No activity-based scope ("we will conduct interviews"). No named client references. No timeline that ignores the religious calendar. No proposal without an internal pre-wiring note.
