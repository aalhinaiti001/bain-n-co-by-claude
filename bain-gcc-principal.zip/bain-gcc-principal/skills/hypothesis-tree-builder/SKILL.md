---
name: hypothesis-tree-builder
description: Convert a vague business question into a day-one hypothesis and a MECE issue tree with a prioritized, 80/20 analysis plan. Use whenever the user presents a broad or unstructured problem ("figure out why margins are falling", "how should we think about X"), asks to structure a problem, build an issue tree, define workstreams, or plan analyses — even if they don't use the word "hypothesis."
---

# Hypothesis Tree Builder

## Trigger conditions
- Any unstructured or multi-part business question.
- "Structure this" / "build the issue tree" / "what would the workplan be?"
- The first substantive step of any new case, before data gathering.

## Required inputs
1. The question as posed, verbatim.
2. The decision it must inform and who decides (link to `skills/stakeholder-power-map` if unknown).
3. Time and data constraints; for GCC work, note data-scarcity expectations up front (`skills/gcc-data-triangulation`).

## Process
1. **Sharpen the question** into a single decision-oriented sentence with a deadline and decision-maker. If the user's question is really two questions, say so and split it.
2. **State the day-one hypothesis**: a specific, falsifiable answer, with a one-line rationale. Wrong is fine; vague is not.
3. **Build the tree** (use `templates/issue-tree.md`):
   - Level 1: 3–5 branches that are mutually exclusive and collectively exhaustive against the sharpened question.
   - Level 2: sub-hypotheses phrased as testable statements, not topics ("Channel mix shift explains most of the margin decline", not "Channels").
   - MECE check: name what would fall through the gaps, or confirm nothing does.
4. **Attach the kill test** to each sub-hypothesis: the single analysis or fact that would disprove it, its data source (or `[VERIFY]` + triangulation route), and effort (S/M/L).
5. **Sequence 80/20**: rank branches by (a) impact on the answer, (b) speed to test. The top 2–3 tests are Week 1 work. Everything else waits.
6. **Log assumptions** into `templates/assumption-log.md` as they are made.
7. **GCC overlay**: for each branch, flag where the evidence path runs through relationships rather than data (e.g., regulator intent, family shareholder appetite) and route those to the stakeholder plan rather than to desk research.

## Output structure
1. Sharpened question (one sentence).
2. Day-one hypothesis (one sentence + rationale).
3. Issue tree (indented text or Mermaid), each node with kill test, source, effort.
4. Week-1 priority list (2–3 items) with owners.
5. Assumption log seed.

## Anti-patterns
No topic-label trees ("Market / Competition / Operations") without testable statements. No tree with more than 5 top branches. No analysis plan that tests the hypothesis it likes first rather than the one that swings the answer.
