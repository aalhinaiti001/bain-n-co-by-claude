---
name: market-entry-assessment
description: Structure and run a GCC market-entry or expansion assessment (KSA, UAE, Qatar, Kuwait, Bahrain, Oman) the way a Bain case team would — hypothesis-led, regulator- and localization-aware, with an explicit go/no-go answer. Use whenever the user asks about entering, expanding into, launching in, or assessing attractiveness of any GCC market or sector, including "should we enter", "market opportunity in", "expansion strategy for", or comparing GCC countries as entry candidates — even if they only ask for "a market overview."
---

# Market Entry Assessment (GCC)

## Trigger conditions
- Any request to assess entry, expansion, launch, or attractiveness of a GCC market/sector.
- Country prioritization questions ("KSA vs. UAE first?").
- Requests for "market overview" where the underlying decision is clearly entry — reframe to the decision.

## Required inputs
Ask for (or state assumptions on) the minimum set, then proceed:
1. Client identity/archetype (see `references/client-archetypes.md`) and home market.
2. Product/service and target segment.
3. Decision at stake (greenfield, JV, acquisition, licensing) and timeline.
4. Constraints: capital envelope, risk appetite, existing GCC presence, localization exposure.

## Process
1. **State the day-one hypothesis** as a falsifiable go/no-go with entry mode ("Enter KSA via JV with a licensed local partner within 18 months; do not enter Qatar in this wave").
2. **Build the issue tree** (use `templates/issue-tree.md`) on four branches, kept MECE:
   - *Market attractiveness*: demand drivers tied to the national agenda (`references/national-vision-agendas.md`), competitive intensity, pricing dynamics. All sizes `[VERIFY]` with a stated triangulation route (`skills/gcc-data-triangulation`).
   - *Ability to win*: right to play, differentiation vs. incumbents and regional champions, partner/wasta network requirements, talent access.
   - *Entry economics*: investment, path to breakeven, capital and profit repatriation mechanics `[VERIFY per jurisdiction]`.
   - *Feasibility and risk*: licensing/foreign-ownership rules `[VERIFY]`, Nitaqat/Emiratisation exposure, sponsor dependence, calendar and decision-cycle realities.
3. **Sequence 80/20**: identify the 2–3 killer analyses (usually: regulatory feasibility, one anchor-customer/partner test, unit economics) and run those first.
4. **Stakeholder overlay**: run `skills/stakeholder-power-map` on the target market's gatekeepers — regulator, anchor partner, relevant SWF or GRE if the sector touches the national agenda.
5. **Stress the soft-no risk**: for JV/partnership routes, flag where enthusiasm may be politeness and specify the private validation step before committing.
6. **Answer**: go/no-go, entry mode, sequencing, top three risks with mitigations, and the first 90 days.

## Output structure
Use `templates/engagement-readout.md`. One-page answer first; issue tree, assumption log, and stakeholder map as appendices. Every figure sourced or `[VERIFY]`. Every recommendation carries an owner and a date.

## Anti-patterns
No country attractiveness matrices built on invented scores. No entry recommendation that ignores localization or licensing feasibility. No "phased optionality" language that avoids the go/no-go.
