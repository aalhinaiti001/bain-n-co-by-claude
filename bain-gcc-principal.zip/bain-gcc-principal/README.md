# bain-gcc-principal

A Claude Code project encoding the working identity, method, and tacit operating norms of a Bain & Company Principal/Partner with 15 years of GCC experience. Invoke it to get hypothesis-led structuring, answer-first writing, and GCC-institutional judgment — including the layer that never appears in scope documents: real-decision-maker mapping, soft-no reading, pre-wiring discipline, calendar realities, and data-scarcity triangulation.

## What this is

- A **persona and method scaffold**: `CLAUDE.md` loads on every invocation and sets the operating contract; `/skills/` fire on task triggers; `/references/` hold durable market and cultural-practice context; `/templates/` are output shells.
- All cultural content is written as **institutional and professional convention** — operational guidance, never national-character claims. Keep it that way when extending.
- **No statistics anywhere.** Every quantity is `[VERIFY]` with a stated verification route. The `gcc-data-triangulation` skill converts placeholders into defensible estimates when you supply or gather evidence.

## What this is not

- **Not licensed advice.** Nothing this project produces is legal, tax, regulatory, audit, or investment advice in any GCC jurisdiction. Licensing regimes, localization quotas, foreign-ownership rules, agency law, and tax treatments change frequently and vary by emirate/free zone/entity type — engage licensed counsel and advisors in-jurisdiction before acting.
- **Not a source of facts.** It supplies structure and judgment; it will refuse to invent market sizes, citations, or precedent cases.
- **Not affiliated with Bain & Company.** "Bain-style" here means the public method tradition (answer-first, issue trees, results orientation) as a persona spec.
- **Not for political analysis** of GCC governments or policy debates — it will describe policy only as client operating context.

## Setup

```bash
# Place the directory anywhere and open it as a Claude Code project
cd bain-gcc-principal
claude
```

`CLAUDE.md` is picked up automatically. Skills follow the `skills/<name>/SKILL.md` convention; if your Claude Code version expects skills under `.claude/skills/`, symlink or copy:

```bash
mkdir -p .claude && ln -s ../skills .claude/skills
```

No dependencies, scripts, or network access required.

## File tree

```
bain-gcc-principal/
├── CLAUDE.md
├── README.md
├── skills/
│   ├── market-entry-assessment/SKILL.md
│   ├── client-proposal-writer/SKILL.md
│   ├── stakeholder-power-map/SKILL.md
│   ├── hypothesis-tree-builder/SKILL.md
│   ├── executive-readout/SKILL.md
│   └── gcc-data-triangulation/SKILL.md
├── references/
│   ├── gcc-market-structure.md
│   ├── national-vision-agendas.md
│   ├── sector-taxonomy.md
│   ├── client-archetypes.md
│   └── tacit-operating-norms.md
└── templates/
    ├── proposal.md
    ├── engagement-readout.md
    ├── steering-committee-update.md
    ├── issue-tree.md
    └── assumption-log.md
```

## Invocation examples

- *Structuring:* "A Saudi family conglomerate asked us why their retail arm's margins are eroding. Structure the problem." → expects a sharpened question, day-one hypothesis, MECE tree with kill tests, Week-1 priorities.
- *Market entry:* "European medtech client wants to enter KSA or UAE first. Assess." → expects go/no-go framing, licensing/localization feasibility flagged, `[VERIFY]` discipline, stakeholder overlay.
- *Proposal:* "Draft a proposal for a GRE tourism authority on operator selection." → expects agenda framing, module-based scope, calendar-aware timeline, internal pre-wiring note.
- *Readout:* "Turn this 30-page analysis into what we tell the SteerCo." → expects one page, answer first, ask/owner/date, private pre-wiring note.
- *Judgment:* "The client CEO said 'inshallah, we'll review after Eid' about our fee proposal. Read it." → expects soft-no diagnosis and a private re-approach plan through the sponsor.
- *Numbers:* "How big is the Saudi private-K-12 market?" → expects a triangulation plan with routes and confidence framing, not an invented figure.

## Extending

- New sectors → add to `references/sector-taxonomy.md`.
- New client patterns → `references/client-archetypes.md`, following the optimizes-for / decision-reality / risks / implications structure.
- New skills → follow the existing frontmatter pattern; every skill must state triggers, required inputs, process, output structure, and anti-patterns.
- Keep `CLAUDE.md` under ~1,200 words — depth goes in `/references/`.

## First-run checklist

1. Ask an unstructured problem → confirm it answers with a hypothesis and MECE tree, not a topic list.
2. Ask for a market size → confirm you get `[VERIFY]` plus a triangulation route, never a number.
3. Describe a client saying "we'll study it, inshallah" → confirm it reads a probable soft no and proposes private re-approach via the sponsor.
4. Request a KSA recommendation → confirm one precise Vision 2030 framing sentence and a localization check appear.
5. Ask it to criticize a senior client in a group deck → confirm it refuses the public framing and routes the message to a private channel.
