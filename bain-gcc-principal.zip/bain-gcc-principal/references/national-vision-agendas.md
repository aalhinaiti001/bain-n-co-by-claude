# National Vision Agendas — Framing Layer

Purpose: every recommendation touching a government, GRE, SWF, or agenda-exposed private client must connect to the relevant national agenda in one precise sentence. This file gives the vocabulary. Program structures evolve — `[VERIFY current program names and status]` before citing in client documents.

## How to use agenda framing

1. **One sentence, specific.** Name the pillar or program the recommendation advances ("expands non-oil private-sector employment under Vision 2030's economy pillar"), not "aligned with the Vision."
2. **Framing, not flattery.** The agenda link must be causally true. A forced link reads worse than none.
3. **It cuts both ways.** Agenda alignment is also a screen: a recommendation that works against a national priority (e.g., heavy expatriate-staffing models in a Saudization-priority sector) needs redesign, not better wording.
4. **Private clients too.** Family groups and multinationals increasingly justify investment internally via agenda alignment because it shapes licensing, land, financing, and SWF partnership access.

## KSA — Vision 2030

- **Structure.** Three pillars (vibrant society, thriving economy, ambitious nation) executed through Vision Realization Programs — among them Quality of Life, Financial Sector Development, Health Sector Transformation, National Industrial Development and Logistics (NIDLP), Privatization, and sector strategies (tourism, sports, culture, gaming, mining) `[VERIFY current program list]`.
- **Executors.** PIF and portfolio/giga-project companies; ministries and their delivery authorities; new regulators for opened sectors.
- **Framing notes.** Localization of jobs and supply chains, non-oil GDP, tourism/entertainment demand creation, and industrial localization are the recurring value-language. Post-2030 planning discourse exists — check current framing at time of use.

## UAE — "We the UAE 2031" and Centennial 2071

- **Structure.** "We the UAE 2031" (forward economy, forward society, forward diplomacy, forward ecosystem) as the decade frame; UAE Centennial 2071 as the long horizon; operational programs like the D33 Dubai Economic Agenda and Abu Dhabi's industrial and falcon-economy strategies sit beneath `[VERIFY current program names]`.
- **Framing notes.** Trade and investment hub language, advanced-tech and AI adoption, talent attraction, and non-oil export growth. Emirate-level agendas often matter more than the federal frame — match the client's emirate.

## Qatar — National Vision 2030 / NDS3

- **Structure.** Four development pillars (human, social, economic, environmental) operationalized through the Third National Development Strategy `[VERIFY current strategy period]`.
- **Framing notes.** Economic diversification beyond LNG-funded state activity, private-sector development, knowledge economy, and post-2022 asset utilization.

## Kuwait — Vision 2035 ("New Kuwait")

- **Structure.** Seven pillars including a northern-region/economic-zone ambition and financial/trade hub positioning `[VERIFY current status]`.
- **Framing notes.** Execution has historically trailed ambition due to institutional gridlock; frame recommendations as executable within current machinery, and treat vision citations more lightly than in KSA.

## Bahrain — Economic Vision 2030 and recovery plans

- **Structure.** Sustainability, competitiveness, fairness as the vision frame; nearer-term economic recovery/fiscal balance programs carry the actual targets `[VERIFY current plan]`.
- **Framing notes.** Fiscal sustainability, financial-services depth, and employment of nationals dominate.

## Oman — Vision 2040

- **Structure.** Themes across people/society, economy/development, governance, environment; executed through five-year plans and OIA portfolio strategy `[VERIFY current five-year plan]`.
- **Framing notes.** Diversification (logistics, tourism, mining, green hydrogen), Omanization, fiscal discipline, and SME development.

## Red lines

- No political commentary on the merits, politics, or personalities of any agenda. Describe agendas as operating context and demand drivers only.
- No claimed program targets or budget figures without source — targets are frequently revised; use `[VERIFY]`.
