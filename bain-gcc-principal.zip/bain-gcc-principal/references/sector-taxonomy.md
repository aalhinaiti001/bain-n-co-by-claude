# GCC Sector Taxonomy

Working taxonomy for scoping, staffing, and issue-tree construction. For each sector: what defines its GCC structure and the questions that recur. No figures; all sizing via `skills/gcc-data-triangulation`.

## 1. Energy and utilities
Hydrocarbons (NOC-dominated value chains: Aramco, ADNOC, QatarEnergy, KPC, OQ), power and water (IPP/IWPP procurement models, single-buyer offtakers), renewables and hydrogen (state-champion-led gigaprojects). Recurring questions: localization of supply chains (e.g., iktva-style programs `[VERIFY]`), decarbonization portfolio choices, utility corporatization.

## 2. Financial services
Banks (concentrated national champions, ongoing consolidation), Islamic finance as a parallel full stack, insurance (fragmented, underpenetrated framing common `[VERIFY]`), asset/wealth management, fintech under sandbox regimes (SAMA, CBUAE, CBB), exchanges and capital-markets deepening (IPO programs). Recurring questions: digital attacker economics, SME lending, market-entry licensing paths, DIFC/ADGM vs. onshore booking.

## 3. Government and public sector
Ministries, delivery authorities, regulators, municipal/city bodies. Recurring questions: operating-model design, privatization/PPP readiness, service digitization, sector-strategy development. Note: the "client" is usually a program office; the decision-maker is above it.

## 4. Sovereign and institutional investment
SWFs and their platforms (see client archetypes). Recurring questions: mandate design, sector-build strategies, portfolio-company value creation, national-champion creation vs. crowding-out of private capital.

## 5. Real estate, construction, and giga-projects
Master developers (state-backed and family), contractors, facilities management, PropTech. Recurring questions: demand realism vs. announced supply `[VERIFY pipeline vs. delivery]`, project-company operating models, cost escalation, offtake strategy.

## 6. Tourism, entertainment, culture, and sports
Destination development, hospitality operators vs. asset owners, events, aviation-linked tourism flows. Recurring questions: demand generation for created destinations, operator selection, national-agenda demand anchors (religious tourism in KSA is its own vertical with distinct dynamics — Hajj/Umrah capacity, seasonality, and regulatory structure `[VERIFY]`).

## 7. Healthcare and life sciences
Public provision reform (corporatization, payer/provider splits, health clusters in KSA `[VERIFY structure]`), private hospital groups (often family-owned), insurance-driven demand shifts, pharma distribution (agency/distributor models), localization of manufacturing. Recurring questions: PPP models, capacity planning, payor mix evolution.

## 8. Consumer, retail, and F&B
Franchise/agency structures dominated by family conglomerates holding multi-brand portfolios; mall-based retail economics; e-commerce and quick-commerce attackers; food security as a state priority. Recurring questions: brand-portfolio rationalization, direct-vs-franchise transitions by global brands, omnichannel economics, localization of workforce in retail `[VERIFY Nitaqat retail rules]`.

## 9. Industrials and manufacturing
Petrochemicals downstream, metals and mining (KSA mining agenda, Oman/UAE plays), building materials, defense industrialization (localization mandates via GAMI/EDGE-style entities `[VERIFY]`), food processing. Recurring questions: feedstock advantage vs. logistics cost, local-content compliance as market access, export platform viability.

## 10. Logistics and transport
Ports (global operators: DP World, AD Ports, Mwani ecosystems), airlines and airports as national instruments, rail buildout, last-mile and 3PL. Recurring questions: hub competition between GCC states, free-zone-linked logistics models, cold chain.

## 11. TMT and digital
Telcos as quasi-sovereign platforms (stc, e&, Ooredoo, Zain, Omantel) diversifying into ICT/fintech/media; data centers and cloud (sovereignty requirements shape entry `[VERIFY data-residency rules per country]`); AI programs as national priorities; gaming and media buildouts. Recurring questions: telco beyond-core strategies, hyperscaler partnership structures, national AI compute plays.

## 12. Education and human capital
K-12 private operators, higher-ed partnerships and branch campuses, vocational/technical training tied to localization agendas, EdTech. Recurring questions: affordability segmentation, regulator fee controls `[VERIFY per country]`, workforce-development contracts with government.

## 13. Agriculture and food security
State-backed food-security investment vehicles, controlled-environment agriculture, aquaculture, strategic reserves and trading arms. Recurring questions: import-dependency reduction economics, technology viability in arid conditions.

## Taxonomy usage rules
- Scope engagements at the sub-sector level; "healthcare" is not a scope.
- Sector structure varies by country more than sector logic does — always cross this file with `gcc-market-structure.md`.
- Regulated-sector entry questions route first through licensing feasibility, not market attractiveness.
