# Client Archetypes

Five recurring GCC client types. For each: what they optimize for, how decisions actually move, engagement risks, and proposal/readout implications. These are institutional patterns, not judgments about individuals; validate the specific client against the pattern rather than assuming it.

## 1. Sovereign wealth fund / state investor
(PIF, Mubadala, ADQ, ADIA, QIA, KIA, OIA, Mumtalakat and their platform companies)

- **Optimizes for:** mandate delivery — a blend of national-strategy execution, sector creation, and financial returns, weighted differently by fund and even by deal team. Establish the mandate weighting before framing value.
- **Decision reality:** professionalized investment committees coexist with strategy directions set above the fund. Deal teams are often young, credentialed, and fast; final approval can wait on a governance layer with its own calendar. Program priorities can pivot with national-agenda shifts — build pivot risk into workplans.
- **Engagement risks:** scope creep across the portfolio; being commissioned by a platform company while the real evaluator sits at the fund; confidentiality exposure across competing portfolio entities — enforce clean-team discipline.
- **Proposal/readout implications:** mandate-language framing; explicit link to the national agenda; comfort with co-investment/partner structures; benchmark against global SWF practice, anonymized.

## 2. Family conglomerate
- **Optimizes for:** patrimony — long-term family wealth, standing, and continuity — alongside returns. Diversified holdings often originated in trading agencies and franchises; portfolio logic can be historical rather than strategic.
- **Decision reality:** the org chart shows professional management; economic control sits with family principals. Identify which generation holds *economic* control vs. *operational* control — recommendations decidable by a hired CEO differ from those requiring family consensus. Succession is frequently the unstated context of the engagement: a "strategy review" may really be a pre-succession portfolio and governance question. Sibling branches, family councils (where they exist), and the founder's continuing shadow all shape what is sayable in group settings.
- **Engagement risks:** being retained by one branch as ammunition against another — test for this in scoping; recommendations that are analytically right but dynastically impossible; leaking sensitive family-governance observations into written documents.
- **Proposal/readout implications:** discretion in writing (governance observations delivered verbally, privately); patient sequencing; respect-preserving language for legacy businesses being rationalized; never force a public family disagreement.

## 3. Ministry / government-related entity (GRE)
- **Optimizes for:** agenda delivery, visible progress against national KPIs, and standing with the leadership layer above.
- **Decision reality:** the signing client is a program office or deputyship; the effective approver is above them and may never attend a meeting. Leadership rotations can reset engagement sponsorship overnight — maintain relationships one level up and one level across. Procurement rules and local-content/RHQ requirements shape who can even be contracted `[VERIFY per entity]`.
- **Engagement risks:** deliverable-acceptance criteria tied to committee cycles; payment cycles slower than private clients; the "study shelf" fate — reports commissioned to defer decisions. Test in scoping whether the entity wants an answer or wants cover.
- **Proposal/readout implications:** milestone structures aligned to committee calendars; agenda framing mandatory; readouts written to be forwarded upward untouched — assume the minister reads it cold.

## 4. PE portfolio company
(Regional funds and global sponsors' GCC assets)

- **Optimizes for:** exit-horizon value creation; the board seat holding the thesis is the real client even when management commissions the work.
- **Decision reality:** dual-audience dynamics — management wants operational credibility, the sponsor wants thesis validation and speed. Value-creation plans must respect GCC constraints the sponsor's global playbook may ignore: localization quotas in cost programs, agency/franchise contract rigidities, family co-shareholder rights.
- **Engagement risks:** being triangulated between sponsor and management; data rooms thinner than diligence assumed; exit narratives that require `[VERIFY]`-grade market claims.
- **Proposal/readout implications:** answer-first and fast; quantified initiatives with owners and dates; explicit bridge to the exit story; candid feasibility flags on playbook imports.

## 5. Multinational regional HQ
- **Optimizes for:** global headquarters' confidence, regional growth targets, and increasingly the Riyadh-vs-Dubai HQ posture question `[VERIFY RHQ rules]`.
- **Decision reality:** regional leadership often holds a narrower mandate than titles suggest; material decisions route through global category or functional owners in another timezone. Local partners (agents, distributors, JV sponsors) hold contractual and relational positions that constrain strategy more than HQ appreciates.
- **Engagement risks:** recommendations regionally right but politically unsellable to global HQ; underestimating partner-exit costs and legal protections for local agents `[VERIFY agency-law implications per country]`; treating the GCC as one market.
- **Proposal/readout implications:** produce the global-HQ-facing version and the regional version of the argument; quantify partner-restructuring realism; country-by-country granularity, not "MENA" aggregates.

## Cross-archetype rules
1. First scoping question, always: *who evaluates this work, and who can kill it?* Run `skills/stakeholder-power-map`.
2. The commissioning entity is the client; the decision-maker is the audience; they are usually not the same person.
3. Archetypes hybridize (a family group with an SWF co-shareholder; a GRE run like a PE fund). Map the hybrid explicitly rather than forcing one pattern.
