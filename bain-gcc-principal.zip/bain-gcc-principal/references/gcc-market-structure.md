# GCC Market Structure by Country

Institutional structure only — no figures. Any quantity belongs in an assumption log with a source or `[VERIFY]`. Regulatory specifics change frequently; every rule referenced below is `[VERIFY current state]` before it enters client work.

## Saudi Arabia (KSA)

- **Center of gravity.** Largest GCC economy and population; the market where most regional strategies are ultimately won or lost. Riyadh has consolidated as the commercial center, reinforced by the regional-headquarters (RHQ) program tying government contracting access to a Riyadh HQ presence `[VERIFY current rules]`.
- **State architecture.** Vision 2030 governs everything: Vision Realization Programs, sector strategies, and PIF's giga-projects (NEOM, Red Sea, Qiddiya, Diriyah, ROSHN among them) form the demand backbone in construction, tourism, entertainment, and infrastructure. PIF operates as both investor and market-maker — frequently the client, the competitor, and the ecosystem owner simultaneously.
- **Decision topology.** Ministries and their delivery arms, PIF and its portfolio companies, royal-court-adjacent bodies, and large family groups. Formal authority and actual initiative frequently sit in different offices; program-level leadership turnover is common, so relationship maps go stale fast.
- **Localization.** Nitaqat quota system by sector and firm size, plus profession-level Saudization mandates in retail, hospitality, and others `[VERIFY current bands]`. Treat as a binding design constraint on any org, cost, or market-entry case.
- **Data environment.** GASTAT is the statistical authority; ministry portals and Tadawul filings add coverage. Series can be rebased or reclassified as programs evolve — check vintage and definition before trending.

## United Arab Emirates (UAE)

- **Two poles, one federation.** Abu Dhabi (capital, hydrocarbon wealth, ADQ/Mubadala/ADIA, ADNOC ecosystem) and Dubai (trade, logistics, tourism, financial and professional services, family-conglomerate depth). Northern emirates are distinct smaller markets. Never treat "the UAE" as one client environment.
- **Free zones vs. mainland.** DIFC and ADGM run common-law jurisdictions with independent courts and regulators — materially different contracting and employment regimes from mainland `[VERIFY per structure]`. Dozens of sectoral free zones shape where businesses domicile.
- **Localization.** Emiratisation targets for private-sector firms above headcount thresholds, expanding over time `[VERIFY current thresholds]`.
- **Role in regional strategies.** Default regional-HQ location historically; the KSA RHQ program has forced explicit HQ-siting decisions. Expect clients to hold Dubai-vs-Riyadh tension inside their own leadership.
- **Data environment.** Relatively strong: FCSC, emirate-level statistics centers, central bank, free-zone authorities, DFM/ADX filings.

## Qatar

- **Structure.** Compact, high-income market; QIA and its subsidiaries plus state champions (QatarEnergy, Ooredoo, QNB and peers) dominate the commanding heights. Post-2022 World Cup, agenda shifted toward Third National Development Strategy priorities under Qatar National Vision 2030.
- **Decision topology.** Short distance between commercial decisions and state leadership; a small set of institutions and families recur across sectors. Reputation effects are amplified accordingly.
- **Practical notes.** Qatarization applies in energy and key sectors `[VERIFY scope]`. The 2017–2021 rift with neighbors ended (Al-Ula, 2021), but supply-chain and structural memories of it persist in client thinking — treat as operating history, not politics.

## Kuwait

- **Structure.** Wealthy hydrocarbon state with the GCC's most assertive parliament; the National Assembly's friction with government historically slows project approvals and reform execution — build longer decision cycles into any Kuwait workplan. KIA is the sovereign investor; KPC governs the oil value chain.
- **Private sector.** Deep, old merchant-family conglomerates with cross-holdings and board interlocks; family-group mapping matters more than sector mapping.
- **Practical notes.** Expect procurement and approval timelines materially longer than KSA/UAE equivalents; deferral cycles are structural, not personal.

## Bahrain

- **Structure.** Smallest GCC economy; positions as a lower-cost, regulation-forward financial and fintech hub (Central Bank of Bahrain as single regulator). Mumtalakat is the sovereign holding. Close economic linkage to KSA's Eastern Province via the causeway shapes retail, tourism, and labor flows.
- **Practical notes.** Often a pilot or nearshore location within a KSA-centered strategy rather than a standalone thesis.

## Oman

- **Structure.** Vision 2040 under Sultan Haitham emphasizes fiscal discipline, diversification (logistics via Duqm and Salalah, mining, tourism, green hydrogen), and consolidation of state holdings under OIA (Oman Investment Authority).
- **Style.** Deliberate decision cadence; institutional relationships built patiently outlast transactional entry attempts. Omanization requirements apply by sector `[VERIFY]`.

## Cross-cutting structural facts

- **Weekends.** KSA, UAE, Qatar, Bahrain, Oman: Sat–Sun business week alignment has been adopted in most (UAE moved to Mon–Fri with half-day Friday; verify per country and client) `[VERIFY current practice per client]`. Kuwait retains Fri–Sat `[VERIFY]`. Never assume — ask the client their working week in week one.
- **GCC layer.** The GCC itself provides a customs-union and standards layer (GSO), but strategy is set nationally; "GCC strategy" decks that ignore national divergence fail.
- **Currency.** All GCC currencies pegged to USD except Kuwait's basket peg `[VERIFY]` — simplifies cross-border modeling; note it once and move on.
