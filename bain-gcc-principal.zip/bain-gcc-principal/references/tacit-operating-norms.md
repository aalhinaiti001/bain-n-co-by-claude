# Tacit Operating Norms — GCC Engagement Practice

The deep version of what CLAUDE.md summarizes. Everything here is written as operational guidance about institutional and professional convention in GCC business settings. It is not a description of any nationality or people, and it must never be rendered as one in client work or conversation. Individuals vary; organizations vary; when observed behavior contradicts the pattern, the observation wins.

## 1. Relationship precedence

- **Trust is the infrastructure.** Data access, candid steering input, and adoption of recommendations flow through personal trust with specific individuals, built across repeated low-stakes contact before high-stakes asks. Plan for it: early-engagement coffee meetings, majlis attendance when invited, presence at client milestones. These are workplan items, not overhead.
- **Continuity is valued.** Rotating team members off a GCC account resets trust. Flag partner/manager continuity as a commercial asset in proposals and a risk in staffing decisions.
- **Reciprocity is remembered.** Small favors — an introduction, a benchmark shared, help with a side question outside scope — compound. Track them mentally; never invoice-meter goodwill.

## 2. Reading the real decision-maker

- Titles indicate protocol rank, not necessarily decision rights. The real approver may be: a chairman who "retired" from operations, a family principal outside management, a chief of staff, a board member with sovereign ties, or a trusted advisor with no formal role.
- **Diagnostics:** whose calendar do meetings move for; who is briefed before decisions "get made" in meetings; whose silence stalls things; who the sponsor glances at when a hard question lands; whose name is invoked as "we should check with…".
- **The wasta layer**, treated professionally: a web of institutional obligation — who appointed whom, which families and offices are intertwined, which relationships the client cannot strain. Map it as relationship facts with evidence. Use it to sequence conversations, never to imply impropriety, and never write speculative network claims into documents.

## 3. Indirect communication and the soft no

- **Signals that frequently mean polite decline:** "inshallah" attached to a commitment request; "we will study it"; deferral to an unscheduled future meeting; a warm meeting that produces no follow-up; delegation of the follow-up to someone junior; extended silence after a proposal.
- **What not to do:** force a yes/no in public; escalate in writing; repeat the same pitch louder.
- **What to do:** treat the signal as information; go back through the sponsor privately; diagnose which objection is live (price, timing, internal politics, a competing loyalty, or the idea itself); revise; re-approach through the channel the sponsor recommends. A soft no is often a "not like this" or "not yet," and is recoverable if handled quietly.
- **Calibrate the other direction too:** effusive enthusiasm in a meeting is hospitality, not commitment. The commitment signal is a named next step, a date, and an assigned person on the client side.

## 4. Hierarchy, face, and the majlis/diwan pattern

- **Never publicly contradict a senior client.** If a senior figure states something inaccurate in a group setting, do not correct in the room. Options: absorb and address privately afterward; route the correction through the sponsor; or reframe later as "new information." Protecting a senior client's standing in front of their people is a professional obligation and is remembered.
- **Group meetings ratify; they don't decide.** In majlis/diwan-style settings — and in formal steering committees run by clients who carry that convention — the decision was shaped in private conversations beforehand. If you are debating in the meeting, the pre-wiring failed.
- **Pre-wiring protocol:** identify every attendee who could object; brief each privately in influence order; adjust the material for what you learn; let the sponsor carry the recommendation into the room where possible; design the meeting so the senior figure can endorse rather than adjudicate.
- **Seniority in your own team matters.** Match seniority to seniority; a partner-level client expects partner-level presence at key moments. Sending a manager to deliver hard messages reads as disrespect.

## 5. Socializing written recommendations

- Nothing consequential should be seen first in a formal document. Sequence: verbal preview with the sponsor → private previews with key stakeholders → adjusted draft → formal presentation → written record.
- Written documents are durable and forwardable. Anything a client would be embarrassed to see forwarded — governance critique, individual performance observations, family-dynamic commentary — is delivered verbally and privately, and appears in writing only in agreed, neutralized form.
- Assume every deck will eventually be read by someone it discusses.

## 6. National agendas, localization, and workforce framing

- Agenda alignment mechanics live in `national-vision-agendas.md`. The tacit addition: agenda language is also internal currency for your client counterparts — recommendations framed in agenda terms are easier for them to sponsor upward. You are arming your sponsor, not decorating a deck.
- **Nitaqat/Emiratisation/other localization regimes** are binding constraints and sensitive terrain. Frame workforce nationalization as capability-building and compliance reality. Never frame nationals-vs-expatriates as a quality comparison; never write cost cases that read as "nationals are expensive." The professional framing: total workforce cost, capability development path, compliance position, and productivity design.
- Expatriate workforce topics (visa dependence, sponsor arrangements) are handled factually and without editorializing on the system.

## 7. Calendar and cadence

- **Ramadan:** working hours legally shortened; meetings compress into late morning or move to evening; decision appetite drops as the month progresses; the final ten days are effectively closed for new decisions. Iftar invitations are relationship opportunities — accept when possible. Schedule no critical approvals in the last third.
- **Eid al-Fitr and Eid al-Adha:** hard stops with travel tails on both sides.
- **Hajj season:** affects KSA government bandwidth and anything Makkah/Madinah-adjacent well beyond the holiday itself.
- **Summer:** senior decision-makers frequently abroad July–August; steering rhythms thin out.
- **Weekends** vary by country and even by client working pattern `[VERIFY per client]`; cross-border teams must publish a shared calendar in week one.
- **Practical rule:** build the religious and national calendar into the workplan before showing it to anyone. A timeline that lands a decision meeting in Eid week signals inexperience and costs credibility disproportionately.

## 8. Data scarcity discipline

- Assume official series may be lagged, definitionally idiosyncratic, or shaped by policy narrative; assume paid market reports may recycle one another. Method lives in `skills/gcc-data-triangulation`.
- The tacit layer: *asking the client for data is itself a relationship act.* Heavy data requests early, before trust, produce thin responses and quiet resentment. Sequence: small, well-justified requests → demonstrate you used them well → larger asks.
- Practitioner conversations are often the best source in the market — and are also relationship events governed by the norms above.

## 9. Small-market reputation mechanics

- The senior commercial community across the GCC is small and densely connected across boards, funds, families, and majlis circuits. Assume any two senior figures can reach each other in one step.
- Consequences: a leaked document, a blamed client, a public correction, or a failed engagement travels across the market and across borders. Conversely, quiet competence compounds — much GCC business development is referral through this network, not RFPs.
- Reflexes: no client names or identifying war stories anywhere, including "anonymized" stories with guessable details; no criticizing a former client to a current one; treat every social setting as on the record.

## 10. Bain norms in the GCC context

- **True North / results orientation** lands well: agenda-driven clients are measured on delivery, and a consultant oriented to their results (not deliverables) becomes part of their success story.
- **"A Bainie never lets another Bainie fail"** extends to the network: alumni sit inside client organizations across the region; treat every alum as a future colleague and channel.
- **Professional skepticism toward client data** must be exercised without implying the counterpart is careless — frame verification as standard method ("we triangulate everything, including our own numbers").
- **Confidentiality reflex** is amplified by §9: cross-engagement information barriers are both an ethical duty and commercial survival in a market where clients compete and intermarry across boards.

## Guardrail

If any of the above is ever about to be expressed as a claim about what "Arabs," "Gulf people," or any nationality "are like" — stop and rewrite it as what it actually is: a description of how specific institutions and professional settings conventionally operate, subject to variation and change.
